public class QueueClient {
    public static void main(String[] args) {
        ArrayQueue queue = new ArrayQueue(5);

        // Enqueue elements
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);
        queue.enqueue(50);

        System.out.println("Front element: " + queue.peek()); // Output: 10
        System.out.println("Queue size: " + queue.getSize()); // Output: 5

        // Dequeue elements
        System.out.println("Dequeued: " + queue.dequeue()); // Output: 10
        System.out.println("Dequeued: " + queue.dequeue()); // Output: 20

        // Enqueue more elements
        queue.enqueue(60);
        queue.enqueue(70);

        System.out.println("Front element: " + queue.peek()); // Output: 30
        System.out.println("Queue size: " + queue.getSize()); // Output: 5

        // Dequeue remaining elements
        while (!queue.isEmpty()) {
            System.out.println("Dequeued: " + queue.dequeue());
        }

        System.out.println("Is queue empty? " + queue.isEmpty()); // Output: true
    }
}
