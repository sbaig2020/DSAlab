public class Stack {
    private int[] arr; // Declare as an array
    private int size; // Stack size
    private int index = 0; // Current index

    // Constructor
    public Stack(int size) {
        this.size = size;
        arr = new int[size];
    }

    // Push method
    public void push(int element) {
        if (isFull()) {
            System.out.println("Stack is full");
            return;
        }
        arr[index] = element;
        index++;
    }

    // Pop method
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return -1; // Return a sentinel value indicating an error
        }
        return arr[--index];
    }

    // Check if stack is empty
    public boolean isEmpty() {
        return index == 0;
    }

    // Check if stack is full
    public boolean isFull() {
        return index == size;
    }

    // Get current stack size
    public int getSize() {
        return index;
    }
}